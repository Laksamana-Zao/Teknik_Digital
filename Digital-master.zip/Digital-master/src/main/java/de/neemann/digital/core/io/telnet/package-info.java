/*
 * Copyright (c) 2021 Helmut Neemann.
 * Use of this source code is governed by the GPL v3 license
 * that can be found in the LICENSE file.
 */

/**
 * Implement's a telnet connection to the simulator
 */
package de.neemann.digital.core.io.telnet;
